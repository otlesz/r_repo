## This program is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by the
## Free Software Foundation; either version 2, or (at your option) any
## later version.
##
## These functions are distributed in the hope that they will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## The text of the GNU General Public License, version 2, is available
## as http://www.gnu.org/copyleft or by writing to the Free Software
## Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#


#######################################
# Function dataStructures
#######################################
#The purpose of these function to
#functionality
#This function written by Zekai Otles otlesz@gmail.com

#Date of function first written

manuplateData<-function(type=type)
{
	if(type=="split"){
	}else if(type=="group"){

	}else if(type=="bind"){

	}else if(type=="select"){

	}else if(type=="unlist"){

	}else if(type=="unstack"){

	}else if(type=="casting"){

	}else if(type=="lappy"){

	}else if(type=="sappy"){

	
	}else if(type=="appy"){

	}else if(type=="tappy"){

	}else if(type=="paste"){
	}else if(type=="substr"){
	}else if(type=="strsplit"){
	}else if(type=="sub"){
	}else if(type=="gsub"){
	}else if(type=="outer"){
	}else if(type=="matrix"){
	}else if(type=="rowSum"){
	}else if(type=="colSum"){
	}else if(type=="match"){
	}else if(type=="which"){
	}else if(type=="which.min"){
	}else if(type=="which.max"){
	}else if(type=="order"){
	}else if(type=="cut"){
	}else if(type=="list"){
	}else if(type=="dframe"){
	}else if(type=="date"){
	}else if(type=="format"){
	}

}

